  /*
 * Naziv zadatka:
     tajmer2

 * Opis:
     primer komuniciranja UART-om sa racunarom: ukoliko se od racunara primi karakter ili string, prekidna rutina to detektuje i zabelezi u bafer,
     a zatim isti taj struibg vrati UART-om na racunar...

 * Test configuration:
     MCU:             MK64FN1M0VDC12
                      https://www.nxp.com/docs/en/data-sheet/K64P144M120SF5.pdf
     Dev.Board:       Fusion for KINETIS v8
                      https://www.mikroe.com/fusion-for-kinetis
                      ac:UART
     Oscillator:      PLL, 120.000MHz
     Ext. Modules:    None
     SW:              mikroC PRO for ARM
                      http://www.mikroe.com/mikroc-arm
 * Napomene:
     - Ukljuciti USB UART Tx i Rx prekidace (board specific)
     - koristimo Terminal v1.9b za spregu sa racunarom
 */


#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "uart5.h"   //napisani drajver za uart5




#define STIGAO 1
#define PONISTI 0

uint8_t stringUART=0, i=0,a=0;
uint8_t rx_buffer[6];  //definisemo maksimalnu velicinu bafera za RX, da bude 30 karaktera
uint8_t recieve;  //promenjiva u koju cemo smestati primljni karakter iz UART5_D registra




//prekidna rutina za UART5******************************************************

void INT_UART5_RX() iv IVT_INT_UART5_RX_TX ics ICS_AUTO
{

 while ( ( UART5_S1 & UART_S1_RDRF_MASK) == 0 );    /* Wait for received buffer to be full*/

     (void) UART5_S1;           /* Read UART2_S1 register*/  //and clear receprion flag mechanism
     recieve = UART5_D;           /* Read received data*/




       if(recieve!=0x0D)
    {
        rx_buffer[i]=recieve;
        i++;
    }
    else
    {
        recieve=0;
        i=0;
        a=strlen(rx_buffer);
        stringUART=STIGAO;

    }

      PTC_PDOR = ~PTC_PDOR;  //vizuelno da mozemo da vidimo na LED-ovkama da je sve u redu sa prekidnom rutinom

}
//******************************************************************************






void main()
  {

      GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_9);   //Tx pin za UART5 izlazni
      GPIO_Digital_Input(&PTD_PDIR, _GPIO_PINMASK_8);  //Rx pin za UART5 ulazni

      UART5_Inicijalizacija();
      delay_ms(100);                 // nakon inicijalizacije uart-a, mala pauza
      NVIC_IntEnable(IVT_INT_UART5_RX_TX);    //omoguci interrupt za UART5 Rx Tx


      while (1)                      // Endless loop
        {

          if(stringUART==STIGAO){
             Uart5_WriteString(rx_buffer);
             for(a=0;a<5;a++){
             rx_buffer[a]='\0';
             }

              stringUART=PONISTI;

          }

         //primer slanja integer-a na UART:
         //WriteUART5_dec2string(2784);

         Delay_ms(100);


  

         }
  }