  /*
 * Naziv zadatka:
     tajmer2

 * Opis:
     primer komuniciranja UART-om sa racunarom: ukoliko se od racunara primi karakter ili string, prekidna rutina to detektuje i zabelezi u bafer,
     a zatim isti taj struibg vrati UART-om na racunar...

 * Test configuration:
     MCU:             MK64FN1M0VDC12
                      https://www.nxp.com/docs/en/data-sheet/K64P144M120SF5.pdf
     Dev.Board:       Fusion for KINETIS v8
                      https://www.mikroe.com/fusion-for-kinetis
    
     Oscillator:      PLL, 120.000MHz
     Ext. Modules:    None
     SW:              mikroC PRO for ARM
                      http://www.mikroe.com/mikroc-arm
 * Napomene:
     - Ukljuciti USB UART Tx i Rx prekidace (board specific)
     - koristimo Terminal v1.9b za spregu sa racunarom
 */


#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "uart5.h"   //napisani drajver za uart5
#include "OLED_096.h"




#define STIGAO 1
#define PONISTI 0

uint8_t stringUART=0, i=0,a=0;
uint8_t rx_buffer[30];  //definisemo maksimalnu velicinu bafera za RX, da bude 30 karaktera
uint8_t recieve;  //promenjiva u koju cemo smestati primljni karakter iz UART5_D registra
uint8_t timeString[15];
int ii=0;
int hours = 0;
    int minutes = 0;
    int seconds = 0;





//prekidna rutina za UART5******************************************************

   void INT_UART5_RX() iv IVT_INT_UART5_RX_TX ics ICS_AUTO
{

 while ( ( UART5_S1 & UART_S1_RDRF_MASK) == 0 );    /* Wait for received buffer to be full*/

     (void) UART5_S1;           /* Read UART2_S1 register*/  //and clear receprion flag mechanism
     recieve = UART5_D;           /* Read received data*/




       if(recieve!=0x0D)
    {
        rx_buffer[i]=recieve;
        i++;
    }
    else
    {
        recieve=0;
        i=0;
   //     a=strlen(rx_buffer);
        stringUART=STIGAO;

    }

    //  PTC_PDOR = ~PTC_PDOR;  //vizuelno da mozemo da vidimo na LED-ovkama da je sve u redu sa prekidnom rutinom

}
//******************************************************************************


void convertTimeToString(int hours, int minutes, int seconds, char *timeString)
{
    sprintf((char *)timeString, "%02d:%02d:%02d", hours, minutes, seconds);
}


//prekidna rutina tajemara 2
void Timer2_interrupt() iv IVT_INT_PIT2 {
  PIT_TFLG2.TIF = 1;             // pocisti interrupt tajmer fleg
  PTC_PDOR = ~PTC_PDOR;          // Toggle PORTC led's*/

   // Simulacija prolaza vremena
    seconds++;
    if (seconds == 60) {
        seconds = 0;
        minutes++;
        if (minutes == 60) {
            minutes = 0;
            hours++;
            if (hours == 24) {
                hours = 0;
            }
        }
    }
    
}

void Inicijalizacija_Tajmer2(double period){
  //proracun za podesavanje perioda: (120[MHz] /2) * period[s]
  uint32_t Y=0;
  double X=0.0;
  X = 60000000.0 * period;
  Y =(uint32_t) X;
  SIM_SCGC6 |= (1ul << PIT);     // ukljucivanje kloka za periodicne prekide tajmera
  PIT_MCR = 0x00;

  PIT_LDVAL2 = Y;       // Pode�avanje preskalera. (120MHz, 500ms),
                                     //PIT_LDVAL2 = 120 [MHz] / 2 * interval [sec] ,
                                     //pri cemu je ovde interval 0.5 sekundi

  NVIC_IntEnable(IVT_INT_PIT2);  // Enable timer interrupts
  PIT_TCTRL2 = (1 << TIE);              // enable Timer 2 interrupts
  PIT_TCTRL2 |= (1 << TEN);             // start Timer 2

  }




void main()
  {

      GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_9);   //Tx pin za UART5 izlazni
      GPIO_Digital_Input(&PTD_PDIR, _GPIO_PINMASK_8);  //Rx pin za UART5 ulazni

      UART5_Inicijalizacija();
      delay_ms(100);                 // nakon inicijalizacije uart-a, mala pauza
      NVIC_IntEnable(IVT_INT_UART5_RX_TX);    //omoguci interrupt za UART5 Rx Tx
      
      Inicijalizacija_Tajmer2(0.5); //inicijalizujem tajmer na 0.5 [s] interrupt rutinu
     //*************************************************inicijalizacija tajmera2 ******************************************
     GPIO_Digital_Output(&PTC_PDOR, _GPIO_PINMASK_ALL);  // Enable digital output on PORTC
     PTC_PDOR = 0x0000;

 
      GPIO_Digital_Output(&PTE_PDOR, _GPIO_PINMASK_0);   //i2c1 SDA
      GPIO_Digital_Output(&PTE_PDOR, _GPIO_PINMASK_1);   //i2c1 SCK
      I2C1_Init_Advanced(4000000, &_GPIO_Module_I2C1_PE1_0);

          //  oledInit();
          Init_OLED();
          delay_ms(100);
          oledClear();
          
         while(1){
         oledGotoYX(0, 0);  // Postavi kursor na pocetak prvog reda
    convertTimeToString(hours, minutes, seconds, timeString);
           for (ii = 0; timeString[ii] != '\0'; ++ii)
    {
        oledPutChar(timeString[ii]);
    }

    }
    /*  while (1)                      // Endless loop
        {

          if(stringUART==STIGAO){
             Uart5_WriteString(rx_buffer);
             for(a=0;a<29;a++){
             rx_buffer[a]='\0';
             }

              stringUART=PONISTI;

          }

         //primer slanja integer-a na UART:
         //WriteUART5_dec2string(2784);

         Delay_ms(100);




         }   */
  }