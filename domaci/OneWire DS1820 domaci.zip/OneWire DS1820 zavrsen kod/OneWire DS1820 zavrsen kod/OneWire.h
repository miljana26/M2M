
unsigned short ow_reset(void);
unsigned short DS1820_ReadBit(void);
void DS1820_WriteBit(unsigned short bBit);
uint8_t DS1820_ReadByte(void);
void DS1820_WriteByte(uint8_t val_u8);
double DS18B20_get_temp(void);