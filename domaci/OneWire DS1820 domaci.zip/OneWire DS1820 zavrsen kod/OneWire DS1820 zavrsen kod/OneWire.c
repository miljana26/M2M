/*** FILEHEADER ****************************************************************
 *
 *    naziv fajla:    ds1820.h onewire protokol
 *    datum:        25.09.2020
 *    autor:      Branislav Batinic
 *
 *    opis: drajver za DS1820 1-Wire tempraturni senzor (Dallas)
 *
 ******************************************************************************/


#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "uart5.h"     //za debug


/* -------------------------------------------------------------------------- */
/*                         DS1820 tajming parametri                           */
/* -------------------------------------------------------------------------- */

#define DS1820_RST_PULSE       480   /* master reset pulse time in [us] */
#define DS1820_MSTR_BITSTART   2     /* delay time for bit start by master */
#define DS1820_PRESENCE_WAIT   40    /* delay after master reset pulse in [us] */
#define DS1820_PRESENCE_FIN    480   /* dealy after reading of presence pulse [us] */
#define DS1820_BITREAD_DLY     5     /* bit read delay */
#define DS1820_BITWRITE_DLY    100   /* bit write delay */


const unsigned short TEMP_RESOLUTION = 9;
int pdbyte;


/*******************************************************************************
 * FUNKCIJA:   DS1820_Reset
 * SVRHA:    Inicijalizuje DS1820 senzor
 *
 * ULAZ:      -
 * IZLAZ:     -
 * POVRATNA VREDNOST:     FALSE ako je barem jedan senzor na  1-wire magistrali, TRUE u suprotnom
 ******************************************************************************/
unsigned short ow_reset(void)
{
    unsigned short bPresPulse; // ovde ce se smestiti povratna vrednost funkcije, odnosno bit koji se ocita sa one wire pin-a
    DisableInterrupts();// ovo je da sprecimo da se neka prekidna rutina umesa da poremeti tajming
    /* reset pulse */
    GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_0);  // postavljam D0 za izlazni pin
    GPIOD_PCOR |= (1 << 0);  //postavljam vrednost pina na logicku nulu
    delay_us(DS1820_RST_PULSE); /* master reset pulse vreme u [us] */
    GPIOD_PSOR |= (1 << 0);      //postavljam pin na logicku jedinicu
    /* sacekaj dok se pullup 1-wire magistrala postavi na logicku jedinicu */
    delay_us(40);
    /* preuzmi presence impuls: bPresPulse */
    GPIOD_PDDR &= ~(1 << 0);                      // Set DQ pin as input
    while(! ((GPIOD_PDIR & (1 << 0))) );
    delay_us(424);
    EnableInterrupts(); //valja ponovo omoguciti prekidne rutine, da se izvrsavaju redovno
    return bPresPulse;
 }



/*******************************************************************************
 * FUNKCIJA:   DS1820_ReadBit
 * SVRHA:    iscitava jedan bit sa DS1820 senzora.
 *
 * ULAZ:      -
 * IZLAZ:     -
 * POVRATNA VREDNOST:     unsigned short        vrednost bita koji ce biti procitan sa senzora DS1820
 ******************************************************************************/
unsigned short DS1820_ReadBit(void)
{
   unsigned short bBit;
   DisableInterrupts();//iskljucim prekidne rutine da ne remete tajming
   GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_0); //postavimo pin kao izlazni
   GPIOD_PCOR |= (1 << 0);  //logicka nula
   delay_us(DS1820_MSTR_BITSTART);
   GPIO_Digital_Input(&PTD_PDIR, _GPIO_PINMASK_0);  //ulazni pin
   delay_us(DS1820_BITREAD_DLY);
   bBit = (GPIOD_PDIR & (1 << 0));  //preuzmi vrednost sa pina, tj. ocitaj 0 ili 1 , sta je na pinu?
   EnableInterrupts(); //ponovo omogucavam prekidne rutine da nastave svoj posao
   return (bBit);
}


/*******************************************************************************
 * FUNKCIJA:   DS1820_WriteBit
 * SVRHA:    upisuje jedan bit na DS1820 senzor
 *
 * ULAZ:      bBit        vrednost bita koja ce biti upisana
 * IZLAZ:     -
 * POVRATNA VREDNOST:     -
 ******************************************************************************/
void DS1820_WriteBit(unsigned short bBit)
{
   DisableInterrupts();//ponovo iskljucujem prekidne rutine privremeno
   GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_0); //postavim pin kao izlazni
   GPIOD_PCOR |= (1 << 0);  //logicka nula, PORT CLEAR OUTPUT
   delay_us(DS1820_MSTR_BITSTART);
   if (bBit != 0)
   {
      GPIOD_PSOR |= (1 << 0);
   }
   delay_us(100);
   GPIOD_PSOR |= (1 << 0);//logicka jedinica, PORT SET OUTPUT
   EnableInterrupts(); //ukljucujem prekidne rutine ponovo
}


/*******************************************************************************
 * FUNKCIJA:   DS1820_ReadByte
 * SVRHA:    iscitava jedan bajt sa DS1820 senzora
 *
 * ULAZ:      -
 * IZLAZ:     -
 * POVRATNA VREDNOST:     uint8          bajt koji ce biti iscitan sa DS1820
 ******************************************************************************/
uint8_t DS1820_ReadByte(void)
{
   uint8_t i;
   uint8_t value = 0;
   for (i=0 ; i < 8; i++)
   {
      if ( DS1820_ReadBit() )
      {
         value |= (1 << i);
      }
      delay_us(120);
   }
   return(value);
}



/*******************************************************************************
 * FUNKCIJA:   DS1820_WriteByte
 * SVRHA:    Writes a single byte to the DS1820 device.
 *
 * ULAZ:      val_u8         byte to be written
 * IZLAZ:     -
 * POVRATNA VREDNOST:     -
 ******************************************************************************/
void DS1820_WriteByte(uint8_t val_u8)
{
   uint8_t i;
   uint8_t temp;

   for (i=0; i < 8; i++)      /* upisuje byte, jedan po jedan bit */
   {
      temp = val_u8 >> i;     /* siftuje val udenso 'i' mesta */
      temp &= 0x01;           /* kopiraj taj bit u temp */
      DS1820_WriteBit(temp);  /* upisi bit u temp */
   }

   delay_us(105);
}



/*******************************************************************************
 * FUNKCIJA:   DS18B20_get_temp
 * SVRHA:    preuzima informaciju o temperaturi sa senzora.
 *
 * ULAZ:
 * IZLAZ:     double rez, vrednost sa senzora
 * POVRATNA VREDNOST:    rez
 ******************************************************************************/

double DS18B20_get_temp(void)
{
    unsigned int temperatura,temp_res;
    double rez;
     ow_reset();
                      // Onewire reset signal
    DS1820_WriteByte(0xCC);
                //  command SKIP_ROM
    DS1820_WriteByte(0x44);                  //  command CONVERT_T
    delay_us(120);

    ow_reset();

    DS1820_WriteByte(0xCC);

    DS1820_WriteByte(0xBE);                  //  command READ_SCRATCHPAD
    delay_us(120);

    temperatura =  DS1820_ReadByte();
    temperatura = (DS1820_ReadByte() << 8) + temperatura;

    temp_res = temperatura%2;

    temperatura = temperatura/2;


    rez = temperatura + temp_res/2.0;

    return rez/10;
  //  Display_Temperature(temperatura);
}



//  void Display_Temperature(unsigned int temp2write) {
//  const unsigned short RES_SHIFT = TEMP_RESOLUTION - 8;
//  char temp_whole;
//  unsigned int temp_fraction;
//  // Extract temp_whole
//  temp_whole = temp2write >> RES_SHIFT ;
//
//  // Convert temp_whole to characters
//  if (temp_whole/100)
//    text6[0] = temp_whole/100  + 48;
//  else
//    text6[0] = '0';
//
//  text6[0] = (temp_whole/10)%10 + 48;             // Extract tens digit
//  text6[1] =  temp_whole%10     + 48;             // Extract ones digit
//
//  // Extract temp_fraction and convert it to unsigned int
//  temp_fraction  = temp2write << (4-RES_SHIFT);
//  temp_fraction &= 0x000F;
//  temp_fraction *= 625;
//
//  // Convert temp_fraction to characters
// text6[3] =  temp_fraction/1000    + 48;         // Extract ones digit
// if(meni==0){
//  lcd_gotoxy(9,1);
// lcd_putchar(223);
// lcd_gotoxy(10,1);
// lcd_putchar('C');
// lcd_gotoxy(5,1);
// lcd_puts(text6);
// }
//}