/*
 *        LCD interface header file
 *        See lcd.c for more info
 *
 * Copywrite Craig Lee 1998
 */

/* write a byte to the LCD in 4 bit mode */


/*#ifndef LCD.h
#define LCD.h*/

void lcd_write(unsigned char);

void lcd_gotoxy (char line,char pos);

/* Clear and home the LCD */

void lcd_clear(void);

void LcdStrobe();
/* write a string of characters to the LCD */

void lcd_puts(const char * s);

/* Go to the specified position */

void lcd_goto(unsigned char pos);
        
/* intialize the LCD - call before anything else */

void lcd_init(void);

void lcd_putch(unsigned char c);

void lcd_dec2str3(unsigned int x);

void lcd_dec2string(unsigned int x);

void lcd_dec2string_sa_zarazeom( float x);



/*        Set the cursor position */

#define        lcd_cursor(x)        lcd_write(((x)&0x7F)|0x80)
#define         LINE1                        0x00        /* position of line1 */
#define         LINE2                        0x40        /* position of line2 */

/*#endif*/