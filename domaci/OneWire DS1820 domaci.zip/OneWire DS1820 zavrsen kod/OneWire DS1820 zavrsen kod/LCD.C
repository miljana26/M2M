/*
drajver prilagodjen za dspic30f4013

 */


#include "lcd.h"



// LCD module connections
sbit LCD_RS at PTC_PDOR.B10;
sbit LCD_EN at PTC_PDOR.B11;
sbit LCD_D4 at PTD_PDOR.B4;
sbit LCD_D5 at PTD_PDOR.B5;
sbit LCD_D6 at PTD_PDOR.B6;
sbit LCD_D7 at PTD_PDOR.B7;
// End LCD module connections

/*#define  LCD_RS    PTC_PTOR._GPIO_PIN_10
#define  LCD_EN    PTC_PTOR._GPIO_PIN_11
#define  LCD_D4    PTD_PTOR._GPIO_PIN_4
#define  LCD_D5    PTD_PTOR._GPIO_PIN_5
#define  LCD_D6    PTD_PTOR._GPIO_PIN_6
#define  LCD_D7    PTD_PTOR._GPIO_PIN_7*/

#define LCD_line1   0x80 // Line 1 position 1   
#define LCD_line2   0xC0 // Line 2 position 1  

/*#define LCD_RS_Direction  GPIO_PORTC_DIR.B10
#define LCD_EN_Direction  GPIO_PORTC_DIR.B11;
#define LCD_D4_Direction GPIO_PORTD_DIR.B4;
#define LCD_D5_Direction GPIO_PORTD_DIR.B5;
#define LCD_D6_Direction GPIO_PORTD_DIR.B6;
#define LCD_D7_Direction GPIO_PORTD_DIR.B7;*/



//#define        LCD_STROBE        ((LCD_EN = 1),(LCD_EN=0))

void LcdStrobe(){
/*PTC_PTOR._GPIO_PIN_11=1;
      PTC_PTOR._GPIO_PIN_11=0;*/
   LCD_EN = 1;
     delay_us(50);
        LCD_EN = 0;

}

/* write a byte to the LCD in 4 bit mode */

void
lcd_write(unsigned char c)
{
        if(c & 0x80) LCD_D7=1; else LCD_D7=0;
        if(c & 0x40) LCD_D6=1; else LCD_D6=0;
        if(c & 0x20) LCD_D5=1; else LCD_D5=0;
        if(c & 0x10) LCD_D4=1; else LCD_D4=0;
        LcdStrobe();
        if(c & 0x08) LCD_D7=1; else LCD_D7=0;
        if(c & 0x04) LCD_D6=1; else LCD_D6=0;
        if(c & 0x02) LCD_D5=1; else LCD_D5=0;
        if(c & 0x01) LCD_D4=1; else LCD_D4=0;
        LcdStrobe();
        //delay_us(40);
    delay_us(50);
}

/*
 *         Clear and home the LCD
 */

void
lcd_clear(void)
{
        LCD_RS = 0;

        lcd_write(0x1);
        //Delay_ms(2);
Delay_ms(2);  //5
}

/* write a string of chars to the LCD */

void
lcd_puts(const char * s)
{
        LCD_RS = 1;        // write characters

        while(*s) lcd_write(*s++);
}

/* write one character to the LCD */

void
lcd_putch(unsigned char c)
{
        LCD_RS = 1;        // write characters

        lcd_write(c);
}


/*
 * Go to the specified position
 */

void
lcd_goto(unsigned char pos)
{
        LCD_RS = 0;

        lcd_write(0x80 + pos);
}
        
/* initialise the LCD - put into 4 bit mode */


 void lcd_gotoxy (char line,char pos)   // Set DDRAM address     
 {
        LCD_RS = 0;
         switch(line)   
         {   
         case 1: lcd_write((LCD_line1-1)+pos);          
                 break;   
         case 2: lcd_write((LCD_line2-1)+pos);      
         }  
 }  


void lcd_init(void)
{
        LCD_RS = 0;        // write control bytes   Register Select

        Delay_ms(15);// power on delay

        LCD_D4 = 1;        // init!        
        LCD_D5 = 1; //
        LcdStrobe();
        //Delay_ms(5);
Delay_ms(5);//8
        LcdStrobe();        // init!
//        Delay_us(100);
Delay_us(100);//600
        LcdStrobe();        // init!
//        Delay_ms(5);
Delay_ms(5); //8

        LCD_D4 = 0;        // set 4 bit mode
        LcdStrobe();
        //Delay_us(40);
Delay_us(40); //120

//********************za blink kursora ova inicijalizacija************************************
/*lcd_write(0x28);        // 4 bit mode, 1/16 duty, 5x8 font
lcd_write(0x08);        // display off
lcd_write(0x0F);        // display on, blink curson on
lcd_write(0x06);        // entry mode*/
//*********************************************************************************************



//****************bez kursora na ekranu ova inicijalizacija************************************
lcd_write(0x28);// 4 bit mode, 1/16 duty, 5x8 font, 2lines
lcd_write(0x0C);// display on
lcd_write(0x06);// entry mode advance cursor
lcd_write(0x01);// clear display and reset cursor
//*********************************************************************************************
}


// *-----------------------------------------
// *  Konverzija decimalnih brojeva u string
//    u opsegu od 0..999
// *----------------------------------------*/
void lcd_dec2str3(unsigned int x)
{
  unsigned int y;
  if (x<1000)
  {

    y=x/100;lcd_putch(y+0x30);x-=(y*100);
    y=x/10;lcd_putch(y+0x30);x-=(y*10);
    lcd_putch(x+0x30);
  }
  else lcd_puts("Err");
}



void lcd_dec2string(unsigned int x)
{
  unsigned int y;
  if (x<100)
  {

    y=x/10;lcd_putch(y+0x30);x-=(y*10);
    y=x;lcd_putch(y+0x30);x-=(y);
    //lcd_putch(x+0x30);
  }
  else lcd_puts("Err");
}

void lcd_dec2string_sa_zarazeom( unsigned int x)
{
    if (x < 100.0)
  {
    // Prikaz desetica
    unsigned int y = (unsigned int)x;
    lcd_putch(y + 0x30);

    // Dodajte decimalnu tacku
    lcd_putch('.');

    // Prikaz cifara nakon decimalne tacke
    x -= y;
    x *= 10.0;

    y = (unsigned int)x;
    lcd_putch(y + 0x30);
  }
  else
  {
    lcd_puts("Err");
  }
}