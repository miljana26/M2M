  /*
 * Naziv zadatka:
     one wire senzor temperatre DS1820

 * Autor:
      Branislav Batinic
 * Opis:
     primer komuniciranja UART-om sa racunarom: vrednost senzora se periodicno salje na uart, svakih 1 sekund

 * Test configuration:
     MCU:             MK64FN1M0VDC12
                      https://www.nxp.com/docs/en/data-sheet/K64P144M120SF5.pdf
     Dev.Board:       Fusion for KINETIS v8
                      https://www.mikroe.com/fusion-for-kinetis
                      ac:UART
     Oscillator:      PLL, 120.000MHz
     Ext. Modules:    None
     SW:              mikroC PRO for ARM
                      http://www.mikroe.com/mikroc-arm
 * Napomene:
     - Ukljuciti USB UART Tx i Rx prekidace (board specific)
     - koristimo Terminal v1.9b za spregu sa racunarom  , baud rate je 28800 bps
     - DS1820 je povezan na D0 pin > NAPOMENA: senzor DS1820 mora na PULLUP otpornik, jer je open drain izlaz
 */



#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "uart5.h"   //napisani drajver za uart5
#include "LCD.h"
#include "tajmer2.h"
#include "OneWire.h"

#define STIGAO 1
#define PONISTI 0

uint8_t stringUART=0, i=0,a=0;
uint8_t rx_buffer[30];  //definisemo maksimalnu velicinu bafera za RX, da bude 30 karaktera
uint8_t recieve;  //promenjiva u koju cemo smestati primljni karakter iz UART5_D registra

double temperatura=0.0;
   uint8_t temp_string[5];


//prekidna rutina za UART5******************************************************
void INT_UART5_RX() iv IVT_INT_UART5_RX_TX ics ICS_AUTO
   {

    while ( ( UART5_S1 & UART_S1_RDRF_MASK) == 0 );    /* Wait for received buffer to be full*/
    (void) UART5_S1;           /* Read UART2_S1 register*/  //and clear receprion flag mechanism
    recieve = UART5_D;           /* Read received data*/
    if(recieve!=0x0D)
       {
        rx_buffer[i]=recieve;
        i++;
       }
       else
          {
           recieve=0;
           i=0;
           // a=strlen(rx_buffer);
           stringUART=STIGAO;
          }

    //  PTC_PDOR = ~PTC_PDOR;  //vizuelno da mozemo da vidimo na LED-ovkama da je sve u redu sa prekidnom rutinom

}
//******************************************************************************


//prekidna rutina tajemara 2
void Timer2_interrupt() iv IVT_INT_PIT2 {
  PIT_TFLG2.TIF = 1;             // pocisti interrupt tajmer fleg
  PTC_PDOR = ~PTC_PDOR;          // Toggle PORTC led's*/
}







void main(){

     GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_9);   //Tx pin za UART5 izlazni
     GPIO_Digital_Input(&PTD_PDIR, _GPIO_PINMASK_8);  //Rx pin za UART5 ulazni
     UART5_Inicijalizacija();
     delay_ms(100);                 // nakon inicijalizacije uart-a, mala pauza
     NVIC_IntEnable(IVT_INT_UART5_RX_TX);    //omoguci interrupt za UART5 Rx Tx


     //definisanje izlaznih pinova koji se koriste za ispis na displej
     GPIO_Digital_Output(&PTC_PDOR, _GPIO_PINMASK_10);
     GPIO_Digital_Output(&PTC_PDOR, _GPIO_PINMASK_11);
     GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_4);
     GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_5);
     GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_6);
     GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_7);
     PTC_PDOR = 0x0000;
     PTD_PDOR = 0x0000;

     //inicijalizacija displeja
     lcd_init();
     lcd_clear();



     //Inicijalizacija_Tajmer2(0.5); //inicijalizujem tajmer na 0.5 [s] interrupt rutinu
     //*************************************************inicijalizacija tajmera2 ******************************************
     GPIO_Digital_Output(&PTC_PDOR, _GPIO_PINMASK_ALL);  // Enable digital output on PORTC
     PTC_PDOR = 0x0000;

     temperatura = DS18B20_get_temp();


     while (1)                      // Endless loop
        {

          if(stringUART==STIGAO){
             Uart5_WriteString(rx_buffer);
             for(a=0;a<29;a++){
             rx_buffer[a]='\0';
             }

              stringUART=PONISTI;

              }

           //primer slanja integer-a na UART:
           temperatura = DS18B20_get_temp();

           //ako ispisujem u terminalu
         //  sprintf((char *)temp_string, "%.1f C\r",temperatura);
           
           //ako ispisujem na LCD-u
           sprintf((char *)temp_string, "%.1f ",temperatura);
           
           //WriteUART5_dec2string((uint16_t)temperatura);
           
           Uart5_WriteString(temp_string);



             lcd_clear();
             lcd_puts(temp_string);
             for(a=0;a<=strlen(temp_string);a++){
             temp_string[a]='\0';
             }
           
           Delay_ms(1000);


         }





}