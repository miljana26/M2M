
/*#ifndef tajmer2.h
#define tajmer2.h*/


  void Inicijalizacija_Tajmer2(double period);
  
  
  
  
/*#endif*/