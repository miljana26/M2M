
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "display.h"
#include "uart.h"

#define STIGAO 1
#define PONISTI 0

uint8_t stringUART=0, i=0,a=0;
uint8_t rx_buffer[31];  //definisemo maksimalnu velicinu bafera za RX, da bude 30 karaktera
uint8_t recieve=0;  //promenjiva u koju cemo smestati primljni karakter iz UART5_D registra




//prekidna rutina za UART5******************************************************

void INT_UART5_RX() iv IVT_INT_UART5_RX_TX ics ICS_AUTO
{

 while ( ( UART5_S1 & UART_S1_RDRF_MASK) == 0 );    /* Wait for received buffer to be full*/

     (void) UART5_S1;           /* Read UART2_S1 register*/  //and clear receprion flag mechanism
     recieve = UART5_D;           /* Read received data*/




       if(recieve!=0x0D)
    {
        rx_buffer[i]=recieve;
        i++;
    }
    else
    {
        recieve=0;
        i=0;
        a=strlen(rx_buffer);
        stringUART=STIGAO;

    }

      PTC_PDOR = ~PTC_PDOR;  //vizuelno da mozemo da vidimo na LED-ovkama da je sve u redu sa prekidnom rutinom

}
//******************************************************************************


void lcd_puts_wrap(const char *s) {
    lcd_clear();  // Ocisti ekran
    Delay_ms(100);

    lcd_gotoxy(1, 1);  // Postavi kursor na pocetak displeja
    Delay_ms(100);

    lcd_puts(s);

    // Ako ima preostalih karaktera, prebaci na drugu liniju i ispi�i maksimalno 16 karaktera
    if (strlen(s) > 16) {
        lcd_gotoxy(2, 1);
        lcd_puts(s + 16);
    }
}




void main() {

GPIO_Digital_Output(&PTC_PDOR, _GPIO_PINMASK_10);
GPIO_Digital_Output(&PTC_PDOR, _GPIO_PINMASK_11);
GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_4);
GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_5);
GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_6);
GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_7);
PTC_PDOR = 0x0000;
PTD_PDOR = 0x0000;
//UART
GPIO_Digital_Output(&PTD_PDOR, _GPIO_PINMASK_9);   //Tx pin za UART5 izlazni
GPIO_Digital_Input(&PTD_PDIR, _GPIO_PINMASK_8);  //Rx pin za UART5 ulazni

UART5_Inicijalizacija();
delay_ms(100);                 // nakon inicijalizacije uart-a, mala pauza
NVIC_IntEnable(IVT_INT_UART5_RX_TX);    //omoguci interrupt za UART5 Rx Tx


lcd_init();
   lcd_gotoxy(0, 1);  // Postavi kursor na pocetak displeja
   lcd_clear();  // Ocisti ekran
     Delay_ms(100);
     
while (1)                      // Endless loop
{


          if(stringUART==STIGAO){
             //Uart5_WriteString(rx_buffer);
             lcd_clear();  // Ocisti ekran
             Delay_ms(100);
             lcd_gotoxy(1, 1);  // Postavi kursor na pocetak displeja
             Delay_ms(100);
             lcd_puts_wrap(rx_buffer);  // Ispi�i novi tekst na ekranu
             for(a=0;a<=strlen(rx_buffer);a++){
             rx_buffer[a]='\0';
             }

              stringUART=PONISTI;
          }



         Delay_ms(100);
}



}