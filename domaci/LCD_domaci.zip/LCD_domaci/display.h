

void LcdStrobe();

void lcd_write(unsigned char c);

void lcd_clear(void);

void lcd_puts(const char * s);

void lcd_puts_extended(const char *s);

void lcd_putch(unsigned char c);

void lcd_goto(unsigned char pos);

void lcd_gotoxy (char line,char pos);

void lcd_init(void);