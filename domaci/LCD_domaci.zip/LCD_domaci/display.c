#include "display.h"

#define LCD_line1 0x80 // Line 1 position 1
#define LCD_line2 0xC0 // Line 2 position 1

sbit LCD_RS at PTC_PDOR.B10;
sbit LCD_EN at PTC_PDOR.B11;
sbit LCD_D4 at PTD_PDOR.B4;
sbit LCD_D5 at PTD_PDOR.B5;
sbit LCD_D6 at PTD_PDOR.B6;
sbit LCD_D7 at PTD_PDOR.B7;

void LcdStrobe(){
LCD_EN = 1;
delay_us(50);
LCD_EN = 0;
}

void lcd_write(unsigned char c)
{
if(c & 0x80) LCD_D7=1; else LCD_D7=0;
if(c & 0x40) LCD_D6=1; else LCD_D6=0;
if(c & 0x20) LCD_D5=1; else LCD_D5=0;
if(c & 0x10) LCD_D4=1; else LCD_D4=0;
LcdStrobe();
if(c & 0x08) LCD_D7=1; else LCD_D7=0;
if(c & 0x04) LCD_D6=1; else LCD_D6=0;
if(c & 0x02) LCD_D5=1; else LCD_D5=0;
if(c & 0x01) LCD_D4=1; else LCD_D4=0;
LcdStrobe();
delay_us(50);
}

void lcd_clear(void)
{
LCD_RS = 0;
lcd_write(0x1);
Delay_ms(2);
}

void lcd_puts(const char * s)
{
LCD_RS = 1; // write characters
while(*s) lcd_write(*s++);
}


void lcd_putch(unsigned char c)
{
LCD_RS = 1; // write characters
lcd_write(c);
}

void lcd_goto(unsigned char pos)
{
LCD_RS = 0;
lcd_write(0x80 + pos);
}

void lcd_gotoxy (char line,char pos)
{
LCD_RS = 0;
switch(line)
{
case 1: lcd_write((LCD_line1-1)+pos);
break;
case 2: lcd_write((LCD_line2-1)+pos);
}
}

void lcd_init(void)
{
LCD_RS = 0; // write control bytes Register Select
Delay_ms(15);// power on delay
LCD_D4 = 1;
LCD_D5 = 1;
LcdStrobe();
Delay_ms(5);
LcdStrobe();
Delay_us(100);
LcdStrobe();
Delay_ms(5);
LCD_D4 = 0;
LcdStrobe();
Delay_us(40);
lcd_write(0x28);// 4 bit mode, 1/16 duty, 5x8 font, 2lines
lcd_write(0x0C);// display on
lcd_write(0x06);// entry mode advance cursor
lcd_write(0x01);// clear display and reset cursor
}